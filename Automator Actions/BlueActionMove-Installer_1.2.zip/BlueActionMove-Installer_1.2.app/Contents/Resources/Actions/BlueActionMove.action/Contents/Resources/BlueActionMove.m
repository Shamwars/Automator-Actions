//
//  BlueActionMove.m
//
//  Copyright 2005 Framework Labs. All rights reserved.
//

#import "BlueActionMove.h"

#import <IOBluetoothUI/objc/IOBluetoothDeviceSelectorController.h>
#import <IOBluetoothUI/objc/IOBluetoothObjectPushUIController.h>
#import <IOBluetooth/IOBluetoothUtilities.h>

#pragma mark  internal interfaces

@interface BlueActionMove (PrivateMethods)

- (IOBluetoothDevice *)getBluetoothDevice;
- (IOBluetoothDevice *)getPredefinedBluetoothDevice;
- (void)setPredefinedDevice:(IOBluetoothDevice *)dev;
- (void)setPredefinedDeviceName:(NSString *)name address:(NSString *)addr;

@end

#pragma mark  implementations

static IOBluetoothDevice * queryBluetoothDevice ()
{
    // run device selector controller
    IOBluetoothDeviceSelectorController *dsc = 
    	[IOBluetoothDeviceSelectorController deviceSelector];
    int res = [dsc runModal];
    if (res != kIOBluetoothUISuccess) {
        return nil;
    }
    
    // extract first device from result array
    NSArray *devs = [dsc getResults];
    return [devs objectAtIndex:0];
}

@implementation BlueActionMove

- (void)dealloc
{
    [predefinedDevice release];
    [super dealloc];
}

- (id)runWithInput:(id)input fromAction:(AMAction *)anAction 
             error:(NSDictionary **)errorInfo
{ 
    if (input && [input count] > 0) {
    
        // run object push on main thread as we need user IO
        // specifying YES on waitUntilDone: will block this action until work 
        // is completed
        [self performSelectorOnMainThread:@selector(doit:) 
        	withObject:input waitUntilDone:YES];
    } 
    
    // return input array of file-paths unchanged for subsequent actions
    return input;
}

- (IBAction)selectDevice:(id)sender
{
    // prompt user to select a device and store it as predefined
    [self setPredefinedDevice:queryBluetoothDevice()];
}

- (void)doit:(id)input
{
    IOBluetoothDevice *dev = [self getBluetoothDevice];
    if (dev) {
    
        // run push controller
        IOBluetoothObjectPushUIController *opc = 
        	[[IOBluetoothObjectPushUIController alloc] 
                	initObjectPushWithBluetoothDevice:dev 
                       		withFiles:input delegate:nil];    
        [opc runModal];
        
        // no need to release opc as done internally by controller when 
        // specifying nil as delegate
    }
    else {
        NSLog(@"BlueActionMove: aborted because no device specified");
    }
}

@end

@implementation BlueActionMove (PrivateMethods)

- (IOBluetoothDevice *)getBluetoothDevice
{
    // get predefined device - could be nil
    IOBluetoothDevice *dev = [self getPredefinedBluetoothDevice];
    if (!dev) {
    
        // if there is no predefined device, prompt user to define one now
        dev = queryBluetoothDevice();
    }
    return dev;
}

- (IOBluetoothDevice *)getPredefinedBluetoothDevice
{
    // whether we have a predefined device or not is decided by the 
    // 'isPredefined' parameter.
    NSDictionary *params = [self parameters];
    NSNumber *num = [params objectForKey:@"isPredefined"];
    if (num && [num boolValue]) {
    
        // the predefined device should be stored in the temporary instance
        // variable 'predefinedDevice'.
        if (predefinedDevice) {
            return predefinedDevice;
        }
        else {
        
            // if it is not stored there, we have to create the device from the
            // bluetooth address stored in the 'predefinedDeviceAddress' 
            // parameter.
            NSString *addrStr = 
            	[params objectForKey:@"predefinedDeviceAddress"];
            
            // the address string can be undefined or empty
            if (addrStr && ![addrStr isEqualToString:@""]) {
                BluetoothDeviceAddress addr;
                if (IOBluetoothNSStringToDeviceAddress(addrStr, &addr)) {
                    NSLog(@"BlueActionMove: can't convert BT address");
                    return nil;
                }
                predefinedDevice = [[IOBluetoothDevice withAddress:&addr] retain];
                return predefinedDevice;
            }
        }
    }
    return nil;
}

- (void)setPredefinedDevice:(IOBluetoothDevice *)dev
{
    // if the old predefined is the same as argument, just return
    if (predefinedDevice == dev) {
        return;
    }
    
    // if there is an old predefined device, clean it up
    [predefinedDevice release];
        
    // store argument as new predefined device
    predefinedDevice = [dev retain];
    if (predefinedDevice) {
    
        // get device name
        NSString *devName = [predefinedDevice getNameOrAddress];
        
        // get device address
        const BluetoothDeviceAddress *addr = [predefinedDevice getAddress];
        NSString *addrStr = IOBluetoothNSStringFromDeviceAddress(addr);
        
        // store device name and address
        [self setPredefinedDeviceName:devName address:addrStr];
    }
    else {
    
        // clear the predefined device name and address
        [self setPredefinedDeviceName:@"" address:@""];
    }
}

- (void)setPredefinedDeviceName:(NSString *)name address:(NSString *)addr
{
    NSMutableDictionary *params = [self parameters];    
    
    // set the predefined device name
    [params setObject:name forKey:@"predefinedDeviceName"];
    
    // set the predefined device address
    [params setObject:addr forKey:@"predefinedDeviceAddress"];
}

@end
