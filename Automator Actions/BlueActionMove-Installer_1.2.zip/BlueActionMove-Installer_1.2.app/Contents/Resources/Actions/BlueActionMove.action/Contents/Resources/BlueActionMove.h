//
//  BlueActionMove.h
//
//  Copyright 2005 Framework Labs. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <Automator/AMBundleAction.h>

@class IOBluetoothDevice;

@interface BlueActionMove : AMBundleAction
{
    IOBluetoothDevice *predefinedDevice;
}

- (id)runWithInput:(id)input fromAction:(AMAction *)anAction 
             error:(NSDictionary **)errorInfo;
- (IBAction)selectDevice:(id)sender;

@end
