Lock and Unlock Files and Folders

These two actions lock and unlock files and folders in the Finder.

Input: (Files/Folders)

Result: (Files/Folders)


Further Notes

They are separate actions so they don't have to be configured. Just double-click or drag-n-drop to add to a workflow.

Due to the way files and folders are locked and unlocked in the Finder, no errors are returned if something can't be done. I believe the only circumstances would be if you don't have permission to change it, for example, anything not in your home folder. This shouldn't be an issue for anybody, except for those people who don't have permissions. 


Workflow Examples

There are two workflows meant to be used as Finder plug-ins for locking items and unlocking items. You can easily install them with Automator, while at the same time checking to make sure you agree with what the workflow will be doing.   Just choose File > Save As Plug-in... and then select Finder and type a name. This is just too easy. 

If you ever want to change the name of the resulting menu item, just go to your ~/Library/Workflows/ folder. In there you'll find an Applications folder with a Finder folder. Change the names of the workflows inside and the menus will instantly reflect the change.

In fact, I've just now decided to include a workflow that will help you do just that. It's named " Edit Menu..." Open with Automator then save this as a Finder plug-in, too, then you can easily make changes to the menu. 
